// DatabaseHelper.java
package com.example.locationfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LocationFinder.db";
    private static final int DATABASE_VERSION = 1;

    // Table and columns
    private static final String TABLE_NAME = "LocationTable";
    private static final String COL_ID = "id";
    private static final String COL_ADDRESS = "address";
    private static final String COL_LATITUDE = "latitude";
    private static final String COL_LONGITUDE = "longitude";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ADDRESS + " TEXT, " +
                COL_LATITUDE + " REAL, " +
                COL_LONGITUDE + " REAL)";
        db.execSQL(CREATE_TABLE);

        // Insert 100 locations into the database
        insertInitialData(db);
    }

    private void insertInitialData(SQLiteDatabase db) {
        // List of sample locations for the Greater Toronto Area
        String[] locations = {
                "Oshawa", "Ajax", "Pickering", "Scarborough", "Downtown Toronto",
                "Mississauga", "Brampton", "Markham", "Richmond Hill", "Vaughan"
                // Add more as needed up to 100 locations
        };

        // Latitude and longitude placeholders for simplicity; update with real values if available
        double[][] coordinates = {
                {43.8971, -78.8658}, {43.8509, -79.0204}, {43.8390, -79.0868},
                {43.7731, -79.2578}, {43.6532, -79.3832}, {43.5890, -79.6441},
                {43.7315, -79.7624}, {43.8561, -79.3370}, {43.8875, -79.4280},
                {43.8372, -79.5083}
                // Add more corresponding coordinates as needed
        };

        for (int i = 0; i < locations.length; i++) {
            ContentValues values = new ContentValues();
            values.put(COL_ADDRESS, locations[i]);
            values.put(COL_LATITUDE, coordinates[i][0]);
            values.put(COL_LONGITUDE, coordinates[i][1]);
            db.insert(TABLE_NAME, null, values);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // CRUD methods
    public Cursor getLocationByAddress(String address) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, new String[]{COL_ID, COL_LATITUDE, COL_LONGITUDE},
                COL_ADDRESS + "=?", new String[]{address}, null, null, null);
    }

    public Cursor getLocationById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, new String[]{COL_ADDRESS, COL_LATITUDE, COL_LONGITUDE},
                COL_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
    }

    public boolean addLocation(String address, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ADDRESS, address);
        values.put(COL_LATITUDE, latitude);
        values.put(COL_LONGITUDE, longitude);
        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1;
    }

    public boolean deleteLocation(String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME, COL_ADDRESS + "=?", new String[]{address});
        db.close();
        return result > 0;
    }

    public boolean updateLocation(int id, String address, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ADDRESS, address);
        values.put(COL_LATITUDE, latitude);
        values.put(COL_LONGITUDE, longitude);
        int result = db.update(TABLE_NAME, values, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }
}
