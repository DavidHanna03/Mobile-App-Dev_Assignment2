// MainActivity.java
package com.example.locationfinder;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etId, etAddress, etLatitude, etLongitude;
    private TextView tvResult;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etId = findViewById(R.id.etId);
        etAddress = findViewById(R.id.etAddress);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        tvResult = findViewById(R.id.tvResult);

        dbHelper = new DatabaseHelper(this);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnSearch = findViewById(R.id.btnSearch);

        btnAdd.setOnClickListener(v -> {
            String address = etAddress.getText().toString();
            double latitude = Double.parseDouble(etLatitude.getText().toString());
            double longitude = Double.parseDouble(etLongitude.getText().toString());
            if (dbHelper.addLocation(address, latitude, longitude)) {
                Toast.makeText(this, "Location Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to Add Location", Toast.LENGTH_SHORT).show();
            }
        });

        btnDelete.setOnClickListener(v -> {
            String address = etAddress.getText().toString();
            if (dbHelper.deleteLocation(address)) {
                Toast.makeText(this, "Location Deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to Delete Location", Toast.LENGTH_SHORT).show();
            }
        });

        btnUpdate.setOnClickListener(v -> {
            int id = Integer.parseInt(etId.getText().toString());
            String address = etAddress.getText().toString();
            double latitude = Double.parseDouble(etLatitude.getText().toString());
            double longitude = Double.parseDouble(etLongitude.getText().toString());
            if (dbHelper.updateLocation(id, address, latitude, longitude)) {
                Toast.makeText(this, "Location Updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to Update Location", Toast.LENGTH_SHORT).show();
            }
        });

        btnSearch.setOnClickListener(v -> {
            String address = etAddress.getText().toString();
            Cursor cursor = dbHelper.getLocationByAddress(address);
            if (cursor != null && cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                double latitude = cursor.getDouble(cursor.getColumnIndexOrThrow("latitude"));
                double longitude = cursor.getDouble(cursor.getColumnIndexOrThrow("longitude"));
                tvResult.setText("ID: " + id + ", Latitude: " + latitude + ", Longitude: " + longitude);
                cursor.close();
            } else {
                tvResult.setText("Location Not Found");
            }
        });
    }
}
